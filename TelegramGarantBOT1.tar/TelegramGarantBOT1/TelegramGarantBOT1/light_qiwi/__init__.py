# -*- coding: utf-8 -*-
# Written by @vffuunnyy
# https://github.com/vffuunnyy/Light_Qiwi

from light_qiwi.qiwi import *
